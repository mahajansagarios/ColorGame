//
//  ViewController.swift
//  Sagar_Color_Selection_Game
//
//  Created by MACOS on 7/17/17.
//  Copyright © 2017 MACOS. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var v1: UIView!

    @IBOutlet weak var v2: UIView!
    
    var getout = 0;
    var score = 0
    
    override func viewDidLoad() {
        
        let gesture = UITapGestureRecognizer(target: self, action: #selector(self.handle))
        let gesture1 = UITapGestureRecognizer(target: self, action: #selector(self.handle1))
        v1.addGestureRecognizer(gesture);
        v2.addGestureRecognizer(gesture1);
        
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        
    }
    func handle(sender : UITapGestureRecognizer)
    {
       if getout == 1
       {
        var randomRed:CGFloat = CGFloat(drand48())
        
        var randomGreen:CGFloat = CGFloat(drand48())
        
        var randomBlue:CGFloat = CGFloat(drand48())
        
        let array = [45,65];
        let randomIndex = Int(arc4random_uniform(UInt32(array.count)))
        let ri = randomIndex
        if ri == 0 {
            v1.backgroundColor = UIColor(red: randomRed, green: randomGreen, blue: randomBlue, alpha: 0.65)
            v2.backgroundColor = UIColor(red: randomRed, green: randomGreen, blue: randomBlue, alpha: 0.45)
            getout = ri;
            
            
        }
        else
        {
            v1.backgroundColor = UIColor(red: randomRed, green: randomGreen, blue: randomBlue, alpha: 0.45)
            v2.backgroundColor = UIColor(red: randomRed, green: randomGreen, blue: randomBlue, alpha: 0.65)
            getout = ri;
            score = score + 1
            
        }
        score = score + 1
        }
       else{
        let alert = UIAlertController(title: "GameOver", message: "YourScore = \(score)", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "RESTART", style: .default, handler: nil))
        
        self.present(alert, animated: true, completion: nil);
        score = 0;
        }
   
    }
    func handle1(sender : UITapGestureRecognizer)
    {
        if getout == 0
        {
            var randomRed:CGFloat = CGFloat(drand48())
            
            var randomGreen:CGFloat = CGFloat(drand48())
            
            var randomBlue:CGFloat = CGFloat(drand48())
            
            let array = [45,65];
            let randomIndex = Int(arc4random_uniform(UInt32(array.count)))
            let ri = randomIndex
            if ri == 0 {
                v1.backgroundColor = UIColor(red: randomRed, green: randomGreen, blue: randomBlue, alpha: 0.65)
                v2.backgroundColor = UIColor(red: randomRed, green: randomGreen, blue: randomBlue, alpha: 0.45)
                getout = ri;
                
            }
            else
            {
                v1.backgroundColor = UIColor(red: randomRed, green: randomGreen, blue: randomBlue, alpha: 0.45)
                v2.backgroundColor = UIColor(red: randomRed, green: randomGreen, blue: randomBlue, alpha: 0.65)
                getout = ri;
            }
            score = score + 1;
        }
        else
        {
            
            let alert = UIAlertController(title: "GameOver", message: "YourScore = \(score)", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "RESTART", style: .default, handler: nil))
            
            self.present(alert, animated: true, completion: nil);
            score = 0;
        }
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

